// Test entity
class Customer {
	
	String name
	
	String toString() {
		return "${name}"
	}

}