// Test entity
class Project {
	
	String name
	Customer customer
	
	String toString() {
		return "${name}"
	}

}
